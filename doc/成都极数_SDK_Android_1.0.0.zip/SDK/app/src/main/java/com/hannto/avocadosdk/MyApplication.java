package com.hannto.avocadosdk;

import android.app.Application;
import android.content.Context;

import com.alibaba.android.arouter.launcher.ARouter;
import com.hannto.avocado.lib.BluetoothManager;
import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.Logger;

public class MyApplication extends Application {

    private static MyApplication myApplication;

    @Override
    public void onCreate() {
        super.onCreate();
        myApplication = MyApplication.this;
        ARouter.init(myApplication);
        Logger.addLogAdapter(new AndroidLogAdapter());
        BluetoothManager.getInstance().initBluetooth(MyApplication.this);
    }

    public static Context getInstance(){
        return myApplication;
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        ARouter.getInstance().destroy();
    }
}
