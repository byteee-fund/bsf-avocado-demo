package com.hannto.avocadosdk.wlan;

import android.content.Context;
import android.net.nsd.NsdServiceInfo;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.hannto.chengdujishu.R;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.DemoViewHolder> {

    private Context mContext;
    private List<NsdServiceInfo> serviceInfoList;

    // 事件回调监听
    private MyAdapter.OnItemClickListener onItemClickListener;

    public MyAdapter(Context mContext, List<NsdServiceInfo> serviceInfoList) {
        this.mContext = mContext;
        this.serviceInfoList = serviceInfoList;
    }

    @NonNull
    @Override
    public DemoViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_demo, viewGroup, false);
        return new DemoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DemoViewHolder demoViewHolder, final int i) {
        demoViewHolder.mTextName.setText(serviceInfoList.get(i).getServiceName());
        demoViewHolder.mTextType.setText(serviceInfoList.get(i).getServiceType());
//        demoViewHolder.mTextHost.setText(serviceInfoList.get(i).getHost().getHostName());
//        demoViewHolder.mTextPort.setText(serviceInfoList.get(i).getPort());
        demoViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickListener.onItemClick(v, i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return serviceInfoList.size();
    }

    class DemoViewHolder extends RecyclerView.ViewHolder{

        private TextView mTextName;
        private TextView mTextType;
        private TextView mTextHost;
        private TextView mTextPort;
        private TextView mTextRecord;

        public DemoViewHolder(View itemView) {
            super(itemView);
            mTextName = itemView.findViewById(R.id.service_name_value);
            mTextType = itemView.findViewById(R.id.serivce_type_value);
            mTextHost = itemView.findViewById(R.id.serivce_host_value);
            mTextPort = itemView.findViewById(R.id.serivce_port_value);
            mTextRecord = itemView.findViewById(R.id.serivce_text_record_value);
        }
    }

    public void updateData(List<NsdServiceInfo> serviceInfoList) {
        this.serviceInfoList = serviceInfoList;
        notifyDataSetChanged();
    }
    // 添加新的Item
    public void addNewItem(NsdServiceInfo nsdServiceInfo) {
        if(serviceInfoList == null) {
            serviceInfoList = new ArrayList<>();
        }
        serviceInfoList.add(0, nsdServiceInfo);
        notifyItemInserted(0);
    }
    // 删除Item
    public void deleteItem() {
        if(serviceInfoList == null || serviceInfoList.isEmpty()) {
            return;
        }
        serviceInfoList.remove(0);
        notifyItemRemoved(0);
    }

    // ① 定义点击回调接口
    public interface OnItemClickListener {
        void onItemClick(View view, int position);
        void onItemLongClick(View view, int position);
    }

    // ② 定义一个设置点击监听器的方法
    public void setOnItemClickListener(MyAdapter.OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }
}
