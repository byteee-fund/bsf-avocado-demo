package com.hannto.avocadosdk;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.hannto.avocado.lib.BluetoothDiscoverCallback;
import com.hannto.avocado.lib.BluetoothManager;
import com.hannto.avocado.lib.ConnectBluetoothDeviceCallback;
import com.hannto.avocado.lib.bt.export.callback.FileJobCallback;
import com.hannto.avocado.lib.bt.export.callback.JsonResponsCallback;
import com.hannto.avocadosdk.utils.Utils;
import com.hannto.avocadosdk.wlan.BluetoothAdapter;
import com.hannto.chengdujishu.R;
import com.hannto.laser.HanntoError;
import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.Logger;

import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class BluetoothActivity extends AppCompatActivity implements View.OnClickListener,BluetoothDiscoverCallback {

    private static final int RC_CHOOSE_PHOTO = 101;
    private static final int RC_CHOOSE_FW = 102;

    public static String LICENSE = "9ZWI3PGTRIJE";

    BluetoothDevice hanntoDevice;

    private List<BluetoothDevice> hanntoDevices;
    private BluetoothAdapter bluetoothAdapter;

    private Button discoverButton;
    private Button statusButton;
    private Button createButton;
    private Button sendFileButton;
    private Button confirmButton;
    private Button selectButton;
    private Button cancelButton;
    private Button deviceInfoButton;
    private Button resumeButton;
    private Button selectFwButton;
    private Button updateFwButton;
    private Button jobInfoButton;

    private Button disconnectButton;
    private Button loopJobInfo;
    private Button loopStatus;

    private Button getSleepTimeButton;
    private Button getApPwdButton;
    private Button setSleepTimeButton;
    private Button setApPwdButton;

    private Button getJobInfos;
    private Button cleanEngButton;

    private Button mixedButton;

    private EditText copyEditText;
    private EditText sleepTimeEditText;
    private EditText apPwdEditText;

    private RecyclerView mRecyclerView;
    private TextView mRevceivedTextView;
    private TextView mStatusTextView;

    private ImageView selectIamge;

    private boolean isDiscovering = false;
    private boolean isRefuse = false;

    private int currentJobid = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);
        BluetoothManager.getInstance().initSDK(this,LICENSE);
        discoverButton = findViewById(R.id.discover);
        discoverButton.setOnClickListener(BluetoothActivity.this);
        mRecyclerView = findViewById(R.id.service_list);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(BluetoothActivity.this, LinearLayoutManager.VERTICAL, false));
        hanntoDevices = new ArrayList<>();
        bluetoothAdapter = new BluetoothAdapter(BluetoothActivity.this, hanntoDevices);
        bluetoothAdapter.setOnItemClickListener(new BluetoothAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, final int position) {
                hanntoDevice = hanntoDevices.get(position);
                BluetoothManager.getInstance().connectDevice(hanntoDevice, new ConnectBluetoothDeviceCallback() {
                    @Override
                    public void onConnect(boolean isSuccess) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if(isSuccess){
                                    Toast.makeText(BluetoothActivity.this, "连接成功", Toast.LENGTH_LONG).show();
                                    mStatusTextView.setText("已连接");
                                }else{
                                    Toast.makeText(BluetoothActivity.this, "连接断开", Toast.LENGTH_SHORT).show();
                                    mStatusTextView.setText("未连接");
                                }
                            }
                        });
                    }
                });
            }

            @Override
            public void onItemLongClick(View view, int position) {

            }
        });
        mRecyclerView.setAdapter(bluetoothAdapter);

        statusButton = findViewById(R.id.status);
        statusButton.setOnClickListener(BluetoothActivity.this);

        createButton = findViewById(R.id.create);
        createButton.setOnClickListener(BluetoothActivity.this);

        sendFileButton = findViewById(R.id.file);
        sendFileButton.setOnClickListener(BluetoothActivity.this);

        confirmButton = findViewById(R.id.confirm);
        confirmButton.setOnClickListener(BluetoothActivity.this);

        selectButton = findViewById(R.id.select);
        selectButton.setOnClickListener(BluetoothActivity.this);

        cancelButton = findViewById(R.id.cancel);
        cancelButton.setOnClickListener(BluetoothActivity.this);

        deviceInfoButton = findViewById(R.id.device_info);
        deviceInfoButton.setOnClickListener(BluetoothActivity.this);

        resumeButton = findViewById(R.id.resume);
        resumeButton.setOnClickListener(BluetoothActivity.this);

        selectFwButton = findViewById(R.id.selectFw);
        selectFwButton.setOnClickListener(BluetoothActivity.this);

        updateFwButton = findViewById(R.id.update);
        updateFwButton.setOnClickListener(BluetoothActivity.this);

        jobInfoButton = findViewById(R.id.jobinfo);
        jobInfoButton.setOnClickListener(BluetoothActivity.this);

        disconnectButton = findViewById(R.id.btn_disconnect);
        disconnectButton.setOnClickListener(BluetoothActivity.this);

        loopJobInfo = findViewById(R.id.loop_jobinfo);
        loopJobInfo.setOnClickListener(BluetoothActivity.this);

        loopStatus = findViewById(R.id.loop_status);
        loopStatus.setOnClickListener(BluetoothActivity.this);

        getApPwdButton = findViewById(R.id.get_ap_pwd);
        getApPwdButton.setOnClickListener(BluetoothActivity.this);

        setApPwdButton = findViewById(R.id.set_ap_pwd);
        setApPwdButton.setOnClickListener(BluetoothActivity.this);

        getSleepTimeButton = findViewById(R.id.get_sleep_time);
        getSleepTimeButton.setOnClickListener(BluetoothActivity.this);

        setSleepTimeButton = findViewById(R.id.set_sleep_time);
        setSleepTimeButton.setOnClickListener(BluetoothActivity.this);

        getJobInfos = findViewById(R.id.getJobInfos);
        getJobInfos.setOnClickListener(BluetoothActivity.this);

        cleanEngButton = findViewById(R.id.clean_eng);
        cleanEngButton.setOnClickListener(BluetoothActivity.this);

        mixedButton = findViewById(R.id.mixed);
        mixedButton.setOnClickListener(BluetoothActivity.this);

        mRevceivedTextView = findViewById(R.id.received_message);
        mStatusTextView = findViewById(R.id.statusTextView);

        selectIamge = findViewById(R.id.selectImage);
        copyEditText = findViewById(R.id.job_copies_editview);
        sleepTimeEditText = findViewById(R.id.sleep_time_editview);
        apPwdEditText = findViewById(R.id.ap_pwd_editview);


        if(ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            //做申请权限处理
            ActivityCompat.requestPermissions(this,new String[]
                    {Manifest.permission.WRITE_EXTERNAL_STORAGE},2);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.discover:
                if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
                    //做申请权限处理
                    ActivityCompat.requestPermissions(this,new String[]
                            {Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},3);
                }else{
                    discover();
                }
                break;
            case R.id.status:
                BluetoothManager.getInstance().getDeviceStatus(new JsonResponsCallback() {
                    @Override
                    public void onResponse(JSONObject response) {
                        mRevceivedTextView.setText(response.toString());
                    }

                    @Override
                    public void onErrorResponse(HanntoError error) {
                        mRevceivedTextView.setText("查询status失败");
                    }
                });
                break;
            case R.id.create:

                if(timerJobInfo != null){
                    timerJobInfo.cancel();
                }
                if(timerTaskJobInfo!=null){
                    timerTaskJobInfo.cancel();
                }

                if(timerStatus != null){
                    timerStatus.cancel();
                }

                if(timerTaskStatus != null){
                    timerTaskStatus.cancel();
                }

                printjob(false, getCopies());
                break;
            case R.id.file:
//                sendFile();
                break;
            case R.id.confirm:
//                confirmJob();
                break;
            case R.id.select:
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !isRefuse){
                    if(!Environment.isExternalStorageManager()){
                        Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                        intent.setData(Uri.parse("package:"+getPackageName()));
                        startActivityForResult(intent,1024);
                    }else{
                        choosePhoto();
                    }
                }else{
                    if(ContextCompat.checkSelfPermission(this, Manifest.permission.MANAGE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
                        //做申请权限处理
                        ActivityCompat.requestPermissions(this,new String[]
                                {Manifest.permission.MANAGE_EXTERNAL_STORAGE},6);
                    }else{
                        choosePhoto();
                    }
                }
                break;
            case R.id.cancel:
                cancelJob();
                break;
            case R.id.device_info:
                queryDeviceInfo();
                break;
            case R.id.resume:
                resume();
                break;
            case R.id.selectFw:
//                Toast.makeText(this, "暂未开放", Toast.LENGTH_SHORT).show();
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !isRefuse){
                    if(!Environment.isExternalStorageManager()){
                        Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                        intent.setData(Uri.parse("package:"+getPackageName()));
                        startActivityForResult(intent,1024);
                    }else{
                        chooseFwFile();
                    }
                }else{
                    if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
                        //做申请权限处理
                        ActivityCompat.requestPermissions(this,new String[]
                                {Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE},6);
                    }else{
                        chooseFwFile();
                    }
                }
                break;
            case R.id.update:
//                Toast.makeText(this, "暂未开放", Toast.LENGTH_SHORT).show();

                if(timerJobInfo != null){
                    timerJobInfo.cancel();
                }
                if(timerTaskJobInfo!=null){
                    timerTaskJobInfo.cancel();
                }

                if(timerStatus != null){
                    timerStatus.cancel();
                }

                if(timerTaskStatus != null){
                    timerTaskStatus.cancel();
                }

                printjob(true, 1);
                break;
            case R.id.btn_disconnect:
                disconnectWlan();
                break;
            case R.id.jobinfo:
                getJobInfo(currentJobid);
                break;
            case R.id.loop_jobinfo:
                startLoopJobInfo();
                break;
            case R.id.loop_status:
                startLoopStatus();
                break;
            case R.id.get_ap_pwd:
                getApPwd();
                break;
            case R.id.set_ap_pwd:
                setApPwd();
                break;
            case R.id.get_sleep_time:
                getSleepTime();
                break;
            case R.id.set_sleep_time:
                setSleepTime();
                break;
            case R.id.getJobInfos:
                ArrayList<Integer> list = new ArrayList<>();
                list.add(currentJobid);
                getJobInfos(list);
                break;
            case R.id.clean_eng:
                cleanEng();
                break;
            case R.id.mixed:
                mixed();
                break;
        }
    }

    private void mixed() {
        BluetoothManager.getInstance().getMixedStatus(new JsonResponsCallback() {
            @Override
            public void onResponse(JSONObject response) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mRevceivedTextView.setText(response.toString());
                    }
                });
            }

            @Override
            public void onErrorResponse(HanntoError error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mRevceivedTextView.setText("获取Mixed异常");
                    }
                });
            }
        });
    }

    private void cleanEng() {
        BluetoothManager.getInstance().clean(new JsonResponsCallback() {
            @Override
            public void onResponse(JSONObject response) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mRevceivedTextView.setText(response.toString());
                    }
                });
            }

            @Override
            public void onErrorResponse(HanntoError error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mRevceivedTextView.setText("cleanEng失败");
                    }
                });
            }
        });
    }

    private void setApPwd() {
        Toast.makeText(this, "蓝牙设备不支持", Toast.LENGTH_SHORT).show();
    }

    private void getApPwd() {
        Toast.makeText(this, "蓝牙设备不支持", Toast.LENGTH_SHORT).show();
    }

    private void setSleepTime() {
        Toast.makeText(this, "蓝牙设备不支持", Toast.LENGTH_SHORT).show();
    }

    private void getSleepTime() {
        Toast.makeText(this, "蓝牙设备不支持", Toast.LENGTH_SHORT).show();
    }


    private int getCopies(){
        int copy = 1;
        try {
            copy = Integer.valueOf(copyEditText.getText().toString());
        } catch (Exception e) {
            e.printStackTrace();
            copy = 1;
        }
        if(copy > 9 || copy < 1){
            copy = 1;
        }
        return copy;
    }

    private void disconnectWlan() {
        BluetoothManager.getInstance().disconnectDevice();
    }

    private void discover() {
        android.bluetooth.BluetoothAdapter adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
        if(!adapter.isEnabled()){
            Toast.makeText(BluetoothActivity.this,"请打开蓝牙",Toast.LENGTH_SHORT).show();
            return;
        }
        hanntoDevices.clear();
        updateList();
        if(!isDiscovering){
            BluetoothManager.getInstance().startBTDiscover(this);
        } else {
            showToast("Service discovery stop");
            BluetoothManager.getInstance().stopDiscoveryBluetooth();
        }
    }

    private void queryDeviceInfo(){
        BluetoothManager.getInstance().getDeviceInfo(new JsonResponsCallback() {
            @Override
            public void onResponse(JSONObject response) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mRevceivedTextView.setText(response.toString());
                    }
                });
            }

            @Override
            public void onErrorResponse(HanntoError error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Logger.e("error==>"+error.getMessage());
                        mRevceivedTextView.setText("获取打印机状态失败");
                    }
                });
            }

        });
    }

    private void getJobInfo(int jobId){
        BluetoothManager.getInstance().getJobInfo(jobId, new JsonResponsCallback() {
            @Override
            public void onResponse(JSONObject response) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mRevceivedTextView.setText(response.toString());
                    }
                });

            }

            @Override
            public void onErrorResponse(HanntoError error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mRevceivedTextView.setText("获取任务状态失败");
                    }
                });
            }

        });
    }

    private void getJobInfos(ArrayList<Integer> jobIds){
        Toast.makeText(this, "蓝牙设备不支持", Toast.LENGTH_SHORT).show();
    }

    private Timer timerJobInfo;
    private TimerTask timerTaskJobInfo;
    private Timer timerStatus;
    private TimerTask timerTaskStatus;

    private void startLoopJobInfo() {
        if(timerJobInfo != null){
            timerJobInfo.cancel();
        }
        if(timerTaskJobInfo!=null){
            timerTaskJobInfo.cancel();
        }
        timerJobInfo = new Timer();
        timerTaskJobInfo = new TimerTask() {
            @Override
            public void run() {
                BluetoothManager.getInstance().getJobInfo(currentJobid, new JsonResponsCallback() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void onResponse(JSONObject response) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                mRevceivedTextView.setText("轮询jobinfo成功 = "+response);
                                Logger.w("轮询jobinfo成功 = "+response);
                            }
                        });

                    }

                    @SuppressLint("SetTextI18n")
                    @Override
                    public void onErrorResponse(HanntoError error) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                mRevceivedTextView.setText("轮询jobinfo失败");
                                Logger.w("轮询jobinfo失败");
                            }
                        });
                    }
                });
            }
        };
        timerJobInfo.schedule(timerTaskJobInfo, 20, 3000);

    }

    int count = 0;
    private void startLoopStatus() {
        if(timerStatus != null){
            timerStatus.cancel();
        }
        if(timerTaskStatus!=null){
            timerTaskStatus.cancel();
        }
        timerStatus = new Timer();
        timerTaskStatus = new TimerTask() {
            @Override
            public void run() {
                BluetoothManager.getInstance().getDeviceStatus(new JsonResponsCallback() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void onResponse(JSONObject response) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                mRevceivedTextView.setText("轮询status成功 = "+response.toString());
                                Logger.w("轮询status成功 = "+response.toString());
                            }
                        });
                    }

                    @SuppressLint("SetTextI18n")
                    @Override
                    public void onErrorResponse(HanntoError error) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                mRevceivedTextView.setText("轮询status失败");
                                Logger.w("轮询status失败 count = " + (++count));
                            }
                        });
                    }
                });
            }
        };
        timerStatus.schedule(timerTaskStatus, 20, 3000);

    }

    private void resume(){
        BluetoothManager.getInstance().resume(new JsonResponsCallback() {
            @Override
            public void onResponse(JSONObject response) {
                mRevceivedTextView.setText(response.toString());
            }

            @Override
            public void onErrorResponse(HanntoError error) {
                mRevceivedTextView.setText("获取打印机状态失败");
            }
        });
    }

    private void cancelJob(){
        BluetoothManager.getInstance().cancelJob(0, currentJobid, new JsonResponsCallback() {
            @Override
            public void onResponse(JSONObject response) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mRevceivedTextView.setText(response.toString());
                    }
                });
            }

            @Override
            public void onErrorResponse(HanntoError error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mRevceivedTextView.setText("取消任务失败");
                    }
                });
            }
        });
    }

    private void printjob(boolean isFirmUpdata, int copies) {

        FileJobCallback.FileJobProgressListener sendFileListener = new FileJobCallback.FileJobProgressListener() {

            @Override
            public void onProgressChange(int max, int current, int jobId) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mRevceivedTextView.setText("传输进度："+current);
                    }
                });
            }

            @Override
            public void onCreateJobSuccess(int jobId) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        currentJobid = jobId;
                        mRevceivedTextView.setText("jobId: "+jobId);
                    }
                });
            }

            @Override
            public void onCreateJobFail(int errorCode, String errorReason) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mRevceivedTextView.setText("创建任务失败 error = "+errorCode);
                    }
                });
            }

            @Override
            public void onTransferCompleted(int jobId) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mRevceivedTextView.setText("传输进度结束 结果：成功");
                    }
                });
            }

            @Override
            public void onResponse(byte[] response) {

            }

            @Override
            public void onErrorResponse(HanntoError error) {

            }
        };
        if (isFirmUpdata) {
            if (TextUtils.isEmpty(fwPath) || !new File(fwPath).exists()) {
                showToast("请先指定FW文件");
                return;
            }
            BluetoothManager.getInstance().updateFw(fwPath, sendFileListener);
        } else {
            if (TextUtils.isEmpty(tempPath) || !new File(tempPath).exists()) {
                showToast("请先选图");
                return;
            }
            BluetoothManager.getInstance().createJob(tempPath,copies,sendFileListener);
        }

    }


    private void choosePhoto() {
        Intent intentToPickPic = new Intent(Intent.ACTION_PICK, null);
        intentToPickPic.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
        startActivityForResult(intentToPickPic, RC_CHOOSE_PHOTO);
    }

    private void chooseFwFile(){
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");//设置类型，我这里是任意类型，任意后缀的可以这样写。
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent,RC_CHOOSE_FW);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(data==null){
            return;
        }
        switch (requestCode) {
            case RC_CHOOSE_PHOTO:
                Uri uri0 = data.getData();
                String filePath = Utils.getFilePathByUri(this, uri0);

                if (!TextUtils.isEmpty(filePath)) {
                    RequestOptions requestOptions1 = new RequestOptions().skipMemoryCache(true).diskCacheStrategy(DiskCacheStrategy.NONE);
                    //将照片显示在 ivImage上
                    tempPath = filePath;
                    Glide.with(this).load(filePath).apply(requestOptions1).into(selectIamge);
                }
                break;
            case RC_CHOOSE_FW:
                Uri uri1 = data.getData();//得到uri，后面就是将uri转化成file的过程。
                String filePath1 = Utils.getFilePathByUri(this, uri1);
                Toast.makeText(BluetoothActivity.this, filePath1, Toast.LENGTH_SHORT).show();
                fwPath = filePath1;
                break;
            case 1024:
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
                    if(Environment.isExternalStorageManager()){
                        isRefuse = false;
                    }else{
                        isRefuse = true;
                    }
                }
                break;
        }
    }
    private String tempPath = Environment.getExternalStorageDirectory().getPath() + File.separator + "DCIM/Camera/timg.jpg";
    private String fwPath = "";

    private void showToast(String content){
        Toast.makeText(BluetoothActivity.this, content, Toast.LENGTH_LONG).show();
    }

    private void updateList(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                bluetoothAdapter.updateData(hanntoDevices);
            }
        });
    }

    @Override
    public void onDiscoveryStarted() {
        Logger.d("Service discovery started");
        showToast("Service discovery started");
        isDiscovering = true;
    }

    @Override
    public void onDeviceFound(BluetoothDevice hanntoDevice) {
        if(!hanntoDevices.contains(hanntoDevice)){
            hanntoDevices.add(hanntoDevice);
            updateList();
        }
    }

    @Override
    public void onDiscoveryStopped() {
        isDiscovering = false;
    }
}
