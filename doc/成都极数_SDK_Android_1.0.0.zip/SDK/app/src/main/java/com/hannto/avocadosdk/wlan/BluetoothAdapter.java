package com.hannto.avocadosdk.wlan;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.net.nsd.NsdServiceInfo;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.hannto.chengdujishu.R;

import java.util.ArrayList;
import java.util.List;

public class BluetoothAdapter extends RecyclerView.Adapter<BluetoothAdapter.DemoViewHolder> {
    private Context mContext;
    private List<BluetoothDevice> hanntoDevices;

    // 事件回调监听
    private OnItemClickListener onItemClickListener;

    public BluetoothAdapter(Context mContext, List<BluetoothDevice> hanntoDevices) {
        this.mContext = mContext;
        this.hanntoDevices = hanntoDevices;
    }

    @NonNull
    @Override
    public BluetoothAdapter.DemoViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_demo, viewGroup, false);
        return new DemoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BluetoothAdapter.DemoViewHolder demoViewHolder, @SuppressLint("RecyclerView") final int i) {
        demoViewHolder.mTextName.setText(hanntoDevices.get(i).getName());
        demoViewHolder.mTextType.setText("");
        demoViewHolder.mTextTypeTitle.setVisibility(View.GONE);
//        demoViewHolder.mTextHost.setText(serviceInfoList.get(i).getHost().getHostName());
//        demoViewHolder.mTextPort.setText(serviceInfoList.get(i).getPort());
        demoViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickListener.onItemClick(v, i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return hanntoDevices.size();
    }

    class DemoViewHolder extends RecyclerView.ViewHolder{

        private TextView mTextName;
        private TextView mTextType;
        private TextView mTextHost;
        private TextView mTextPort;
        private TextView mTextRecord;
        private TextView mTextTypeTitle;

        public DemoViewHolder(View itemView) {
            super(itemView);
            mTextName = itemView.findViewById(R.id.service_name_value);
            mTextType = itemView.findViewById(R.id.serivce_type_value);
            mTextTypeTitle = itemView.findViewById(R.id.serivce_type_key);
            mTextHost = itemView.findViewById(R.id.serivce_host_value);
            mTextPort = itemView.findViewById(R.id.serivce_port_value);
            mTextRecord = itemView.findViewById(R.id.serivce_text_record_value);
        }
    }

    public void updateData(List<BluetoothDevice> hanntoDevices) {
        this.hanntoDevices = hanntoDevices;
        notifyDataSetChanged();
    }
    // 添加新的Item
    public void addNewItem(BluetoothDevice hanntoDevice) {
        if(hanntoDevices == null) {
            hanntoDevices = new ArrayList<>();
        }
        hanntoDevices.add(0, hanntoDevice);
        notifyItemInserted(0);
    }
    // 删除Item
    public void deleteItem() {
        if(hanntoDevices == null || hanntoDevices.isEmpty()) {
            return;
        }
        hanntoDevices.remove(0);
        notifyItemRemoved(0);
    }

    // ① 定义点击回调接口
    public interface OnItemClickListener {
        void onItemClick(View view, int position);
        void onItemLongClick(View view, int position);
    }

    // ② 定义一个设置点击监听器的方法
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }
}
